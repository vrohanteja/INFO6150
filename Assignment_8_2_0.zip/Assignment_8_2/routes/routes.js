const express = require('express');
const bodyPraser = require('body-parser');

// use Router from Express, and export it using module.exports
const router = express.Router();
module.exports = router;

// Import database model
const Model = require('../models/model');

// HTTPS methods
// router is taking the route as the first parameter. Then in the second parameter it's taking a callback.
// In the callback, we have a res and a req. res means sending response, and req means receiving request to our client like Postman, or the front-end page

//Post Method
// The function needs to be asynchronous to work, so using async for request - and await to save data.
router.post('/post', bodyPraser.json(), async (req, res) => {

    // A combo of two strings, first name is 1-15 letters long, space, and last name 0-15 letters
    var regExFullName = /^[A-Za-z\s]{1,15}[\.]{0,1}[A-Za-z\s]{0,15}$/;
    // anystring@northeastern.edu
    var regExEmailId = /^[A-Za-z0-9._%+-]+@northeastern\.edu$/;
    // Atleast one number, atleast one alphabet, total alphanumeric string of length 8-16(?=.*\d.*)(?=.*[a-zA-Z].*)[0-9A-Za-z]+
    var regExPass = /^(?=.*\d.*)(?=.*[a-zA-Z].*)[a-zA-Z0-9]{8,16}$/;

    // posting any new data to our database model
    const data = new Model({
        fullname: req.body.fullname,
        email: req.body.email,
        password: req.body.password
    });

    // Try-catch for handling success messages and errors
    try {
        // Validation
        // fullname.trim().match(regExFullName);
        // email.trim().match(regExEmailId);
        // password.trim().match(regExPass);
        // Comment Code Block Ctrl+K+C/Ctrl+K+U

        // if( !fullname.trim().match(regExFullName)){
        //     throw new Exception ("Invalid fullname, please enter alphabets only separated by space");
        // }
        // if( email == null || !email.trim().match(regExEmailId)){
        //     res.status(400);
        //     res.json("Invalid email, please use a valid northeastern email id");
        //     return;
        // }
        // if( password == null || !password.trim().match(regExPass)){
        //     res.status(400);
        //     res.json("Please recheck, and enter a valid 8-16 alpha numeric password");
        //     return;
        // }

        // Save, and store data. Sedn success.
        const dataToSave = await data.save();
        res.status(200).json(dataToSave);
        console.log("data save successful");
    }
    catch (error) {
        res.status(400).json({ message: "hello" });
        console.log("Data not saved!");
    }
})

//Get all Method
router.get('/user/getAll', async (req, res) => {
    try {
        // Use the Model.find method to fetch all the data from the database, and then return json
        const data = await Model.find();
        res.json(data)
    }
    catch (error) {
        res.status(500).json({ message: error.message })
    }
})

//Get by ID (email) Method
router.get('/getById/:id', async (req, res) => {
    try {
        const data = await Model.findById(req.params.id);
        res.json(data)
    }
    catch (error) {
        res.status(500).json({ message: error.message })
    }
})

//Delete by ID Method
router.delete('/delete/:id', (req, res) => {
    res.send('Delete by ID API')
})