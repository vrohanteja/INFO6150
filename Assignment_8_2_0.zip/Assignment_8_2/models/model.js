// Model that will define our database structure.

// Initialize mongoose
const mongoose = require('mongoose');

// Schema that defines our database structure with a name, an email, and a password property - all required.
const dataSchema = new mongoose.Schema({
    fullname: {
        required: true,
        type: String
    },
    email: {
        required: true,
        type: String
    },
    password: {
        required: true,
        type: String
    }
})

// Export schema model
module.exports = mongoose.model('Data', dataSchema)